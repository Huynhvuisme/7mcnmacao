
<?php $__env->startSection('content'); ?>
    <div class="container p-0 px-md-3">
        <div class="d-block d-lg-flex justify-content-between">
            <div class="main-content mt-2 mt-md-4 mr-md-4 p-0 p-md-0">
                <div class="heading-home-page text-center">
                    <h1 class="font-22 font-weight-bold mb-0 text-title box-news"><?php echo getSiteSetting('site_title'); ?></h1>
                </div>
                <?php if(!empty($url7M)): ?>
                <div class="ty-so-7m">
                    <iframe class="w-100 h-2000 iframe-scroll" src='<?php echo e($url7M ?? ""); ?>'></iframe>
                </div>
                <?php endif; ?>
                <div class="my-2 d-none d-lg-block">
                    <?php echo getBanner('center-pc')?>
                </div>

            </div>
            <?php echo $__env->make('web.block._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        <div class="mt-3 main-content post-content mx-2 mx-lg-0">
            <?php
                $siteContent = getSiteSetting('site_content');
            ?>
            <?php echo $siteContent; ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    let status = true,
        btnLoadSite = document.getElementsByClassName('load-site-content')[0],
        siteContent = document.getElementsByClassName('site-content')[0];

        btnLoadSite.addEventListener('click', function(){
            if(status){
                siteContent.classList.remove('text-limit')
            }else{
                siteContent.classList.add('text-limit')
            }
            status = (!status);
        });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make(TEMPLATE, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/web/home/index.blade.php ENDPATH**/ ?>