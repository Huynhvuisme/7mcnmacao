
<?php $__env->startSection('content'); ?>
    <main class="c-main">
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/admin/home/index.blade.php ENDPATH**/ ?>