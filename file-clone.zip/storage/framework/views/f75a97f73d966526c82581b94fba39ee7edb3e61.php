<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="/admin/css/coreui/coreui.min.css">
    <link rel="stylesheet" href="/admin/css/select2.min.css">
    <link rel="stylesheet" href="/admin/css/custom.css?2">
    <link rel="stylesheet" href="/admin/css/toastr.min.css">
    <title><?php echo e(!empty(getCurrentControllerTitle()) ? 'Quản lý '.getCurrentControllerTitle() : 'Admin'); ?></title>
</head>
<body>
<?php echo $__env->make('admin.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="c-wrapper c-fixed-components">
    <?php echo $__env->make('admin.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="c-body">
        <?php echo $__env->yieldContent('content'); ?>
        <?php echo $__env->make('admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
<script src="/admin/js/coreui/coreui.bundle.min.js"></script>
<script src="/admin/js/toastr.js"></script>
<script src="/admin/js/select2.full.min.js"></script>
<script src="/admin/js/custom.js?<?php echo e(time()); ?>"></script>
<script src="/admin/js/tinymce.min.js"></script>
<script src="/admin/js/tiny_full_featured.js?12"></script>
<script src="/admin/js/jquery.nestable.js"></script>
<script src="/admin/js/seo_tool.js?<?php echo e(time()); ?>"></script>
<?php echo $__env->yieldPushContent('scripts'); ?>
</body>
</html>
<?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/admin/layout.blade.php ENDPATH**/ ?>