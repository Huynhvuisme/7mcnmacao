<footer class="container text-grey font-13 w-100 px-0">
    <div class="ft-content py-3 pt-lg-5 pb-lg-3 bg-green4 px-md-3 px-3">
        <div class="row">
            <div class="col-12 col-md-2">
                <a class="mb-3 d-block text-center text-md-left float-left mr-3" href="/">
                    <img src="/web/images/logo-7mcn88.jpg" alt="logo" width="150" height="43" class="img-fluid" >
                </a>
            </div>
            <div class="col-12 col-md-7 d-flex align-items-center">
                <div class="m-0 font-weight-lighter text-white about-footer" style="line-height: 20px;">
                    <?php echo getSiteSetting('site_content_footer'); ?>

                </div>
            </div>
            <div class="col-12 col-md-3 mt-2 d-lg-block p-lg-0 font-weight-lighter about-footer">
                <div class="d-flex justify-content-center">
                    <?php $arrSocial = [
                        'social_facebook' => 'facebook',
                        'social_twitter' => 'twitter',
                        'social_youtube' => 'youtube',
                    ];
                    foreach ($arrSocial as $k => $imageName):?>
                    <a rel="nofollow" target="_blank" href="<?php echo e(getSiteSetting('site_'.$imageName)); ?>" class="btn btn-sm text-white">
                        <img loading="lazy" src="/web/images/icon/<?=$imageName?>.svg" alt="" width="20" height="20">
                    </a>
                    <?php endforeach;?>
                </div>
                <ul class="d-flex justify-content-around list-unstyled">
                    <?php if(!empty($menuFooter)): ?>
                        <?php $__currentLoopData = $menuFooter; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="font-12 my-2 mr-3 mr-lg-0">
                                <a rel="nofollow" href="<?php echo e(getFullUrl($item['url'])); ?>" title="<?php echo e($item['name']); ?>" class="text-gray2"><?php echo e($item['name']); ?></a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>
                </ul>
                <p class="text-right pr-3">Telegram: <a target="_blank" rel="nofollow" href="https://t.me/buffalotru">@buffalotru</a></p>
            </div>
        </div>
    </div>
</footer>
<!--back to top-->
<div class="back-top d-none d-block position-fixed">
    <div class="btn p-0">
        <p class="text-red3 font-weight-bold mb-0 font-16 text-center">TOP</p>
        <p class="text-center">
            <img src="/web/images/icon/back-to-top.png" width="39" height="56" alt="Backtotop">
        </p>
    </div>
</div>
<?php /**PATH D:\work\7mcn88\resources\views/web/footer.blade.php ENDPATH**/ ?>