<?php $__env->startSection('content'); ?>

<link rel="stylesheet" href="/web/css/maytinhdudoan.css">

    <div class="container p-0 px-md-3">

        <div class="d-block d-lg-flex justify-content-between">

            <div class="main-content mt-2 mt-md-4 mr-md-4 p-2 p-md-0">

                <?php if(isset($breadCrumb) && !empty($breadCrumb)): ?>

                    <?php echo getBreadcrumb($breadCrumb); ?>


                <?php endif; ?>



                <?php if(!empty($oneItem->description)): ?>

                    <div class="cat_des text-justify font-16 mb-3">

                        <?php echo $oneItem->description; ?>


                    </div>

                <?php endif; ?>



                <?php if(isset($category_menu)): ?>

                    <div class="list-tournament mb-3">

                        <?php $__currentLoopData = $category_menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <a href="<?php echo e($cate->url); ?>" target="_blank" class="<?php if(strpos(request()->url(), $cate->url)): ?> active <?php endif; ?> btn btn-sm bg-gray cate-tuarnament"><?php echo e($cate->name); ?></a>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php endif; ?>

                



                <?php

                    $titleChidren = json_decode($oneItem->title_children);

                ?>



                <?php if(!$post->isEmpty()): ?>

                    <div class="ft-news mb-3 p-2">

                        <?php echo $__env->make('web.block._top_post', ['posts' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>

                <?php endif; ?>



                <?php if(!empty($totalConner)): ?>

                    <?php $__env->startPush('styles'); ?>

                        <style>

                            <?php echo file_get_contents('web/css/totalcorner.css'); ?>


                        </style>

                    <?php $__env->stopPush(); ?>

                    <div class="total-conner">

                        <?php echo $__env->make('web.block._total_conner', ['tbody' => $totalConner->content], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                    </div>

                <?php endif; ?>

                <?php if(!empty($post)): ?>

                <div class="list-more-posts">

                    <?php echo $__env->make('web.block._load_more_post', ['posts' => $post], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                </div>

                <?php endif; ?>

                <!-- <div class="my-3">

                    <a href="#" data-catid="<?php echo e($oneItem->id ?? 0); ?>" data-page="<?php echo e($page ?? null); ?>" class="btn-cat-load-more d-block bg-grey text-dark p-2 text-center">

                        Tải thêm bài viết

                    </a>

                </div> -->



                <?php if(!empty($oneItem->content)): ?>

                    <div class="cat_des text-justify mb-3 mt-5">

                        <?php echo $oneItem->content; ?>


                    </div>

                <?php endif; ?>

            </div>

            <?php echo $__env->make('web.block._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        </div>

    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make(TEMPLATE, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/web/category/index.blade.php ENDPATH**/ ?>