
<?php $__env->startSection('content'); ?>
    <main class="c-main">
        <div class="container-fluid">
            <div class="fade-in">
                <div class="card">
                    <div class="card-header">
                        Danh sách Nhà cái
                        <div class="card-header-actions pr-1">
                            <a href="/admin/nha_cai/update/<?php echo e($type); ?>"><button class="btn btn-block btn-primary btn-sm mr-3" type="button">Thêm mới</button></a>
                        </div>
                    </div>
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col-4">
                                <select class="form-control" name="category_id" onchange="this.options[this.selectedIndex].value && (window.location = this.options[this.selectedIndex].value);">
                                    <option value="/admin/nha_cai/1" <?php echo e($type == 1 ? 'selected' : ''); ?>>Top nhà cái sidebar</option>
                                    <option value="/admin/nha_cai/2" <?php echo e($type == 2 ? 'selected' : ''); ?>>Nhà cái uy tín</option>
                                    <option value="/admin/nha_cai/3" <?php echo e($type == 3 ? 'selected' : ''); ?>>Game đổi thưởng</option>
                                </select>
                            </div>
                        </div>
                        <table class="table table-striped table-bordered datatable">
                            <thead>
                            <tr>
                                <th class="text-center w-5">Thứ tự</th>
                                <th>Tên nhà cái</th>
                                <th class="text-center w-15">Thao tác</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php if(!empty($listItem)): ?> <?php $__currentLoopData = $listItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($item->order_by); ?></td>
                                    <td><?php echo e($item->name); ?></td>
                                    <td class="text-center">
                                        <a class="btn btn-info" href="/admin/nha_cai/update/<?php echo e($type); ?>/<?php echo e($item->id); ?>">
                                            <svg class="c-icon">
                                                <use xlink:href="/admin/images/icon-svg/free.svg#cil-pencil"></use>
                                            </svg>
                                        </a>
                                        <a class="btn btn-danger" onclick="return confirm('Bạn có chắc muốn xóa?')"
                                           href="/admin/nha_cai/delete/<?php echo e($item->id); ?>">
                                            <svg class="c-icon">
                                                <use xlink:href="/admin/images/icon-svg/free.svg#cil-trash"></use>
                                            </svg>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/admin/nha_cai/index.blade.php ENDPATH**/ ?>