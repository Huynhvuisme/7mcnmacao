<footer class="c-footer">
    <div class="ml-auto">Powered by&nbsp;<a href="https://coreui.io/">CoreUI</a></div>
</footer>
<?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/admin/footer.blade.php ENDPATH**/ ?>