<footer class="c-footer">
    <div class="ml-auto">Powered by&nbsp;<a href="https://coreui.io/">CoreUI</a></div>
</footer>
<?php /**PATH D:\work\7mcn88\resources\views/admin/footer.blade.php ENDPATH**/ ?>