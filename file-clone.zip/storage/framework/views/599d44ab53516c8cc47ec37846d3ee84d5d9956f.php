<script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@type": "website",
    "name": "7mcn88",
    "alternateName": "7mcn88",
    "url": "https://7mcn88.com"
  }
  </script>
<?php /**PATH D:\work\7mcn88\resources\views/web/block/_schema.blade.php ENDPATH**/ ?>