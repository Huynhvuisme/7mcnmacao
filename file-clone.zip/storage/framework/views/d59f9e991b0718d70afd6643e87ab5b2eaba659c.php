
<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('web.block._schema_post', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="container p-0 px-md-3">
        <div class="d-block d-lg-flex justify-content-between">
        <div class="main-content mt-2 mt-md-4 mr-md-4 p-3 p-md-0">
            <?php if(isset($breadcrumb) && !empty($breadcrumb)): ?>
                <?php echo getBreadcrumb($breadcrumb); ?>

            <?php endif; ?>
            <div class="row">
                <div class="col-12 col-md-11">
                    <div class="single-header">
                        <h1 class="font-30 font-weight-bold"><?php echo e($oneItem->title); ?></h1>
                        <div class="font-13 d-flex text-gray3 mb-3">
                        <img class="mr-2" src="/web/images/icon-time.svg" alt="time icon">
                        <?php echo e(date('d/m/Y H:i',strtotime($oneItem->displayed_time))); ?>

                        <b class="ml-2 mb-0 fw-bold" style="color:black;">Tác giả: Trịnh Tuấn</b>
                        </div>
                        <div class="font-weight-bold mb-3 font-16"><?php echo $oneItem->description; ?></div>
                    </div>
                    <?php if(!empty($match)): ?>
                        <div class="border d-none d-lg-flex flex-wrap mb-3">
                            <div class="col-5 border-right d-flex flex-wrap px-0 text-center">
                                <div class="col-6 py-3">
                                    <?php echo genImage($match->team_home_logo, 70, 70, $match->team_home_name, 'img-fluid'); ?>

                                    <span class="font-weight-bold font-14 d-block"><?php echo $match->team_home_name; ?></span>
                                </div>
                                <div class="col-6 py-3">
                                    <?php echo genImage($match->team_away_logo, 70, 70, $match->team_away_name, 'img-fluid'); ?>

                                    <span class="font-weight-bold font-14 d-block"><?php echo $match->team_away_name; ?></span>
                                </div>
                            </div>
                            <div class="col-7 d-flex flex-wrap px-0">
                                <div class="col-6 d-flex pr-0">
                                    <div class="bg-gray1 rounded p-3 align-self-center">
                                        <span class="font-weight-bold d-block mb-2"><?php echo $match->tournament; ?></span>
                                        <span class="font-weight-bold d-block font-14">
                                            <img class="mr-1" src="/web/images/icon-time.svg" alt="time icon" width="18" height="18">
                                            <?php echo e(date('H:i | d/m/Y',strtotime($match->scheduled))); ?>

                                        </span>
                                    </div>
                                </div>
                                <div class="col-6 text-right d-flex flex-column justify-content-center">
                                    <span class="mb-2 font-14"><b><?php echo e($match->hdc_asia); ?></b> (Châu Á)</span>
                                    <span class="mb-2 font-14"><b><?php echo e($match->hdc_eu); ?></b> (Châu Âu)</span>
                                    <span class="font-14"><b><?php echo e($match->hdc_tx); ?></b> (Tài xỉu)</span>
                                </div>
                            </div>
                        </div>
                        <div class="border d-flex d-lg-none flex-wrap mb-3 p-2">
                            <div class="col-3 p-2 text-center">
                                <img class="mb-2" src="<?php echo e($match->team_home_logo); ?>" width="50" height="50">
                                <span class="font-weight-bold font-14 d-block overflow-hidden"><?php echo $match->team_home_name; ?></span>
                            </div>
                            <div class="font-14 col-6 px-0 text-center d-flex flex-column justify-content-center">
                                <span class="mb-1"><b><?php echo e($match->hdc_asia); ?></b> (Châu Á)</span>
                                <span class="mb-1"><b><?php echo e($match->hdc_eu); ?></b> (Châu Âu)</span>
                                <span><b><?php echo e($match->hdc_tx); ?></b> (Tài xỉu)</span>
                            </div>
                            <div class="col-3 p-2 text-center">
                                <img class="mb-2" src="<?php echo e($match->team_away_logo); ?>" width="50" height="50">
                                <span class="font-weight-bold font-14 d-block overflow-hidden"><?php echo $match->team_away_name; ?></span>
                            </div>
                            <div class="col-12 bg-gray1 d-flex justify-content-between py-2">
                                <span class="font-weight-bold"><?php echo $match->tournament; ?></span>
                                <span class="font-weight-bold font-16">
                                    <img class="mr-1" src="/web/images/icon-time.svg" alt="time icon" width="18" height="18">
                                    <?php echo e(date('H:i | d/m/Y',strtotime($match->scheduled))); ?>

                                </span>
                            </div>
                        </div>
                    <?php endif; ?>
                    <?php if(!empty($extra_post_after) || !empty($extra_post_before)): ?>
                        <ul class="bg-gray1 py-2">
                            <?php if(!empty($extra_post_before)): ?>
                                <?php $__currentLoopData = $extra_post_before; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(getUrlPost($value)); ?>" title="<?php echo $value->title; ?>"><?php echo $value->title; ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            <?php if(!empty($extra_post_after)): ?>
                                <?php $__currentLoopData = $extra_post_after; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li>
                                        <a href="<?php echo e(getUrlPost($value)); ?>" title="<?php echo $value->title; ?>"><?php echo $value->title; ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </ul>
                    <?php endif; ?>

                    <div class="line-height-24 entry-content">
                        <?php if(request()->has('lich-su-doi-dau')): ?>
                            <?php echo tableOfContent(preg_replace('#<strong>(.*?)Lịch sử đối đầu(.*?)</strong>#',
                                                            '<strong id="lich-su-doi-dau">Lịch sử đối đầu:</strong>',
                                                            $oneItem->content)); ?>

                        <?php else: ?>
                            <?php echo tableOfContent($oneItem->content); ?>

                        <?php endif; ?>
                    </div>
                    <div class="tag col-sm-12 border-bottom py-3">
                        <strong>Tag:</strong>
                        <?php $__currentLoopData = $oneItem->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <span><a href="<?php echo e(getUrlTag($tag)); ?>"><?php echo e($tag->title); ?> </a> </span>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                     <div class="fb-comments" data-href="<?php echo e(getUrlPost($oneItem)); ?>" data-width="100%" data-numposts="5"></div>
                    <!-- lst news -->
                    

                    
                </div>
            </div>
        </div>
        <?php echo $__env->make('web.block._sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make(TEMPLATE, \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/web/post/index.blade.php ENDPATH**/ ?>