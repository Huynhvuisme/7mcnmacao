<?php $ver = '0.3' ?>
<!DOCTYPE html>
<html lang="vi-VN">
<head>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="robots" content="<?php echo e($seo_data['index'] ?? ''); ?>">
    <title><?php echo e($seo_data['meta_title'] ?? ''); ?></title>
    <?php if(!empty($seo_data['meta_keyword'])): ?>
        <meta name="keywords" content="<?php echo e($seo_data['meta_keyword']); ?>">
    <?php endif; ?>
    <meta name="description" content="<?php echo e($seo_data['meta_description'] ?? ''); ?>">
    <link rel="canonical" href="<?php echo e($seo_data['canonical'] ?? ''); ?>" />
    <meta property="og:title" content="<?php echo e($seo_data['meta_title'] ?? ''); ?>">
    <?php if(!empty($seo_data['site_image'])): ?>
        <meta property="og:image" content="<?php echo e(env('APP_URL').$seo_data['site_image']); ?>">
    <?php endif; ?>
    <meta property="og:site_name" content="7mcn88">
    <meta property="og:description" content="<?php echo e($seo_data['meta_description'] ?? ''); ?>">
    <?php if(!empty($seo_data['published_time'])): ?>
        <meta property="article:published_time" content="<?php echo e($seo_data['published_time']); ?>" />
    <?php endif; ?>
    <?php if(!empty($seo_data['modified_time'])): ?>
        <meta property="article:modified_time" content="<?php echo e($seo_data['modified_time']); ?>" />
    <?php endif; ?>
    <?php if(!empty($seo_data['updated_time'])): ?>
        <meta property="article:updated_time" content="<?php echo e($seo_data['updated_time']); ?>" />
    <?php endif; ?>

    <meta name="twitter:card" content="summary" />
    <meta name="twitter:title" content="<?php echo e($seo_data['meta_title'] ?? ''); ?>" />
    <meta name="twitter:description" content="<?php echo e($seo_data['meta_description'] ?? ''); ?>" />
    <?php if(!empty($seo_data['site_image'])): ?>
        <meta name="twitter:image" content="<?php echo e(url($seo_data['site_image'])); ?>" />
    <?php endif; ?>

    <?php if(isset($home_page)): ?>
    <?php echo $__env->make('web.block._schema', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <script type="application/ld+json">
    {
    "@context":"https://schema.org/",
    "@graph":{"@type":"webpage",
    "@id":"https://7mcn88.com/#webpage",
    "url":"https://7mcn88.com/",
    "inLanguage":"Vi-VN",
    "name":"7MCN88 ⭐️ Tỷ số trực tuyến 7M.CN ma cao - 7M mới nhất",
    "headline":" 7M CN88 - Xem tỷ số trực tuyến 7M.CN Ma Cao mới nhất",
    "description":"7MCN88 là trang Thể thao 7m Livescore - Tỷ số trực tuyến 7m.cn ma cao hôm nay. Cập nhật kết quả bóng đá 7msport, tỷ lệ kèo 2 in1 Châu Á chính xác.",
    "sameAs": [
        "https://about.me/cn887m",
        "https://www.pinterest.com/7mcn88/"
    ]
    }}
</script>
<?php endif; ?>
<?php if(!empty($schema)): ?>
        <?php echo $schema; ?>

    <?php endif; ?>
    <!-- Google tag (gtag.js) -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-SZ2PGDH5QK"></script>
    <script>
    window.dataLayer = window.dataLayer || [];
    function gtag(){dataLayer.push(arguments);}
    gtag('js', new Date());

    gtag('config', 'G-SZ2PGDH5QK');
    </script>
    <meta name='dmca-site-verification' content='eFJMTGE4cXk0b1FQcFpYcnEyVW04QT090' />

    <link rel="shortcut icon" href="<?php echo e(url('images/favicon-7mcn88.jpg')); ?>" />
    <link rel="apple-touch-icon" href="<?php echo e(url('images/favicon-7mcn88.jpg')); ?>" />

    <script defer src="/web/js/jquery.min.js"></script>
    <script defer src="/web/js/non-critical.js?0.01"></script>
    <script defer src="/web/js/custom.js?8"></script>
    <script defer src="/web/js/banner.js?2.01"></script>
    <style>
        <?php echo file_get_contents('web/css/critical.css').file_get_contents('web/css/non-critical.css'); ?>

    </style>
    <?php echo $__env->yieldPushContent('styles'); ?>

    <div id="fb-root"></div>
    <script async defer crossorigin="anonymous" src="https://connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v14.0&appId=1736376983343298&autoLogAppEvents=1" nonce="olYu4Sd0"></script>
</head>
<body>
<?php echo $__env->make('web.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('web.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="fixed-bottom container d-none d-lg-flex flex-column align-items-center mx-auto popup-banner catfish-banner slideInFromLeft">
    <?php echo getBannerPc('catfish-pc'); ?>

</div>
<div class="fixed-bottom d-block d-lg-none popup-banner">
    <?php echo getBannerMobile('catfish-mobile'); ?>

</div>
<div class="float-left position-fixed left-0 popup-banner" style="top:110px;z-index:9999;">
    <?php echo getBannerPc('float-left-pc'); ?>

</div>
<div class="float-right position-fixed right-0 popup-banner" style="top:110px;z-index:9999;">
    <?php echo getBannerPc('float-right-pc'); ?>

</div>
<div class="float-right position-fixed bottom-0 right-0 popup-banner" style="z-index:9999;">
    <?php echo getBannerPc('balloon-right-pc'); ?>

</div>
<div style="position: fixed; right: 5px; top: 400px; width: 75px; z-index: 1030">
    <?php echo getBannerMobile('float-mobile'); ?>

</div>

<!--banner preload-->
<?php if(IS_MOBILE): ?>
    <?php $popup = getBanner('popup-mobile') ?>
<?php else: ?>
    <?php $popup = getBanner('popup-pc'); ?>
<?php endif; ?>
<?php if($popup): ?>
    <div id="adsModal" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content" style="background: none;box-shadow: none;border: none;">
                <div class="modal-body mx-auto">
                    <div class="d-lg-none text-center" style="max-width: 300px">
                        <?php echo $popup; ?>

                    </div>
                    <div class="d-none d-lg-block text-center">
                        <?php echo $popup; ?>

                    </div>
                    <span style="right: 14px;width: 30px;text-align: center;background: rgba(169,169,169,0.8);" class="d-none p-2 position-absolute" data-dismiss="modal"><i class="fa fa-times" aria-hidden="true"></i></span>
                </div>
            </div>
        </div>
    </div>
<?php endif; ?>

<script >
    let is_mobile = (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent));
    let urlAdsMb = `<?php echo e(getBanner('popunder-mobile')); ?>`;
    let urlAdsPc = `<?php echo e(getBanner('popunder-pc')); ?>`;
    if ((urlAdsMb && is_mobile) || (urlAdsPc && !is_mobile)) {
        document.addEventListener('DOMContentLoaded', function () {
            let key = 'checkPopunder';
            let executed = false;

            if (!sessionStorage.getItem(key)) {
                sessionStorage.setItem(key, 1);
                $(document).on('click', 'a:not([target="_blank"][rel="nofollow"])', function (e) {
                    if (!executed) {
                        executed = true;
                        e.preventDefault();
                        openTab(this);
                    }
                });
            }

        });

        function openTab(_this) {
            _this = $(_this);
            let currentUrl = _this.attr('href');
            if (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
                window.open(currentUrl, "_blank");
                window.location = urlAdsMb;
            } else {
                window.open(currentUrl, "_blank");
                window.location = urlAdsPc;
            }
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        $('.popup-banner').on('click', '.banner-close', function (e) {
            $(this).closest('.popup-banner').remove();
        });

        $('#adsModal').on('click', '.banner-close', function (e) {
            $('#adsModal').modal('hide');
        });

    });
</script>

<?php echo $__env->yieldPushContent('scripts'); ?>

</body>
</html>
<?php /**PATH D:\work\7mcn88\resources\views/web/layout.blade.php ENDPATH**/ ?>