
<?php $__env->startSection('content'); ?>
    <main class="c-main">
        <div class="container-fluid">
            <div class="fade-in">
                <div class="card">
                    <div class="card-header">
                        Danh sách bài viết (<?php echo e($total); ?>)
                        <div class="card-header-actions ml-3">
                            <a href="/admin/post/export-excel" id="export-excel" class="btn btn-block btn-primary btn-sm mr-3">Xuất file excel</a>
                        </div>
                        <div class="card-header-actions pr-1">
                            <a href="/admin/post/update"><button class="btn btn-block btn-primary btn-sm mr-3" type="button">Thêm mới</button></a>
                        </div>
                    </div>
                    <div class="card-body">
                        <form method="get" action="">
                            <div class="form-group row">
                                <div class="col-4">
                                    <input type="text" value="<?php echo e($_GET['keyword'] ?? ''); ?>" name="keyword" class="form-control" placeholder="Từ khóa">
                                </div>
                                <div class="col-3">
                                    <select name="category_id" class="form-control">
                                        <option value="">Chuyên mục</option>
                                        <?php $__currentLoopData = $categoryTree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item['id']); ?>" <?php echo e(!empty($_GET['category_id']) && $item['id'] == $_GET['category_id'] ? 'selected': ''); ?>><?php echo e($item['title']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-3">
                                    <select name="user_id" class="form-control">
                                        <option value="">Thành viên</option>
                                        <?php $__currentLoopData = $listUser; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($item['id']); ?>" <?php echo e(!empty($_GET['user_id']) && $item['id'] == $_GET['user_id'] ? 'selected': ''); ?>><?php echo e($item['username']); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <input type="hidden" name="status" value="<?php echo e($_GET['status'] ?? 1); ?>">
                                <div class="col-2">
                                    <input type="submit" class="btn btn-success" value="Tìm kiếm">
                                </div>
                            </div>
                        </form>
                        <table class="table table-striped table-bordered datatable">
                            <thead>
                            <tr>
                                <th class="text-center w-5">ID</th>
                                <th>Tiêu đề</th>
                                <th class="text-center w-15">Chuyên mục</th>
                                <th class="text-center w-15">Tag</th>
                                <th class="text-center w-15">Ngày đăng bài</th>
                                <th class="text-center w-10">Link</th>
                                <th class="text-center w-15">Thao tác</th>
                            </tr>
                            </thead>
                            <tbody>
                            <?php if(!empty($listItem)): ?>
                                <?php $__currentLoopData = $listItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center align-middle"><?php echo e($item->id); ?></td>
                                    <td class="align-middle"><a target="_blank" rel="nofollow" href="<?php echo e(getUrlPost($item)); ?>"><?php echo e($item->title); ?></a></td>
                                    <td class="text-center align-middle">
                                        <ul class="list-unstyled mb-0">
                                        <?php $__currentLoopData = $item->categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><?php echo e($cate->title); ?></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                    <td class="text-center align-middle">
                                        <ul class="list-unstyled mb-0">
                                        <?php $__currentLoopData = $item->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li><a href="<?php echo e(getUrlTag($tag)); ?>"><?php echo e($tag->title); ?></a></li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </ul>
                                    </td>
                                    <td class="text-center align-middle"><?php echo e(date('d-m-Y H:i', strtotime($item->displayed_time))); ?></td>
                                    <td class="text-center align-middle">
                                        <p>Link đi: <span class="font-weight-bold"><?php echo e($item->count_link_out); ?></span></p>
                                        <p class="mb-0">Link về: <span class="font-weight-bold"><?php echo e($item->count_link_ve); ?></span></p>
                                    </td>
                                    <td class="text-center align-middle">
                                        <a class="btn btn-info" href="/admin/post/update/<?php echo e($item->id); ?>">
                                            <svg class="c-icon">
                                                <use xlink:href="/admin/images/icon-svg/free.svg#cil-pencil"></use>
                                            </svg>
                                        </a>
                                        <a class="btn btn-danger" onclick="return confirm('Bạn có chắc muốn xóa?')"
                                           href="/admin/post/delete/<?php echo e($item->id); ?>">
                                            <svg class="c-icon">
                                                <use xlink:href="/admin/images/icon-svg/free.svg#cil-trash"></use>
                                            </svg>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                            </tbody>
                        </table>
                        <?php init_cms_pagination($page, $pagination) ?>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script type="text/javascript">
    window.onload = function () { 
        $('#export-excel').click(function (e) { 
            e.preventDefault();
            let param = window.location.search,
                href = $(this).attr('href');
            location.href = href+param;
        });
    }
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/admin/post/index.blade.php ENDPATH**/ ?>