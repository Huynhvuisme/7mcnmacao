<aside class="sidebar-right pt-4 px-2 px-md-0 w-md-300 d-flex flex-column">
    <?php if(getBanner('top-sidebar')): ?>
        <div class="d-flex justify-content-center mb-3 mw-100" style="height:250px;">
            <?php echo getBanner('top-sidebar'); ?>

        </div>
    <?php endif; ?>
    <?php if($listNhaCai->count()): ?>
        <div>
            <?php echo $__env->make('web.block._nhacai_sidebar', ['listNhaCai' => $listNhaCai], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    <?php endif; ?>
    <?php if(!IS_MOBILE): ?>
        <?php echo $__env->make('web.block._lich_thi_dau_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(IS_MOBILE && !isset($home_page)): ?>
        <?php echo $__env->make('web.block._lich_thi_dau_sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(!empty($football_league_sidebar)): ?>
        <div class="aside-box mb-3">
            <a href="<?php echo e(url('/')); ?>">
                <div class="font-20 font-weight-bold mb-2 d-flex align-items-center">
                    <span class="square-blue mr-2"></span>
                    <div class="ml-1 text-title">SOI KÈO BÓNG ĐÁ</div>
                </div>
            </a>
            <div class="asb-content p-2 bg-white follball-league">
                <?php $__currentLoopData = $football_league_sidebar; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <p class="p-1 mb-2 football-sigle">
                        <a href="<?php echo e($item->link); ?>" class="d-flex text-black align-items-center font-weight-bold">
                            <?php echo genImage($item->thumbnail, '40px', '40px', $item->title, 'img-fluid mr-3'); ?>

                            <?php echo e($item->title); ?>

                        </a>
                    </p>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php endif; ?>

    <?php if(!empty($listKeoPhatGoc)): ?>
        <?php echo $__env->make('web.block._post', ['posts' => $listKeoPhatGoc, 'title'=> 'Kèo Phạt góc hôm nay', 'firstPost' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(!empty($listKeoXien)): ?>
        <?php echo $__env->make('web.block._post', ['posts' => $listKeoXien, 'title'=> 'kèo xiên hôm nay', 'firstPost' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(!empty($listDanhGiaNhaCai)): ?>
        <?php echo $__env->make('web.block._post', ['posts' => $listDanhGiaNhaCai, 'title'=> 'Đánh giá nhà cái'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(!empty($listHuongDanCaCuoc)): ?>
        <?php echo $__env->make('web.block._post', ['posts' => $listHuongDanCaCuoc, 'title'=> 'Hướng dẫn cá cược', 'firstPost' => true, 'fullDes' => true], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <?php endif; ?>
    <?php if(!empty($categoryAuthor)): ?>
        <div class="aside-box mb-3">
            <div class="font-20 font-weight-bold mb-2 d-flex align-items-center">
                <span class="square-blue mr-2"></span>
                <div class="ml-1 text-title">Chuyên gia Soi Kèo</div>
            </div>
            <div class="row mx-2">
                <div class="col-5 p-0">
                    <?php echo genImage($categoryAuthor->avatar_image, 300, 300, $categoryAuthor->name); ?>

                </div>
                <div class="col-7">
                    Pham Bách Phong - CEO & Co-Founder Soi Kèo Số. Hơn 10 năm kinh nghiệm soi kèo, nhận định bóng đá các trận cầu đinh.
                </div>
            </div>
        </div>
    <?php endif; ?>
</aside>
<?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/web/block/_sidebar.blade.php ENDPATH**/ ?>