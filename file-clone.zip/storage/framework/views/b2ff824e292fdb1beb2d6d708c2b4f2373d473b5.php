
<?php $__env->startSection('content'); ?>
    <main class="c-main">
        <div class="container-fluid">
            <div class="fade-in">
                <form method="post" action="">
                    <div class="row">
                        <div class="col-sm-8">
                            <div class="card">
                                <div class="card-header"><strong><?php echo e(!empty($oneItem) ? 'Chỉnh sửa' : 'Thêm mới'); ?> Nhà cái</strong> ( <?php echo e($arr_type[$type]); ?> )</div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-12">
                                            <div class="form-group">
                                                <label>Tên nhà cái</label>
                                                <input class="form-control" required name="name" value="<?php echo e(!empty($oneItem->name) ? $oneItem->name : ''); ?>" type="text" placeholder="Tên nhà cái">
                                            </div>
                                            <div class="form-group">
                                                <label>Mô tả</label>
                                                <textarea class="form-control context" name="content[description]" rows="4" placeholder="Mô tả"><?php echo e(!empty($description) ? $description : ''); ?></textarea>
                                            </div>
                                            <?php if($type == 2): ?>
                                                <div class="form-group">
                                                    <label>Lượt bình chọn</label>
                                                    <input class="form-control" name="content[count]" value="<?php echo e(!empty($count) ? $count : ''); ?>" type="text" placeholder="Lượt bình chọn">
                                                </div>
                                                <div class="form-group">
                                                    <label>Link cược ngay</label>
                                                    <input class="form-control" name="content[link_bet]" value="<?php echo e(!empty($link_bet) ? $link_bet : ''); ?>" type="text" placeholder="Link cược ngay">
                                                </div>
                                                <div class="form-group">
                                                    <label>Link xem review</label>
                                                    <input class="form-control" name="content[link_review]" value="<?php echo e(!empty($link_review) ? $link_review : ''); ?>" type="text" placeholder="Link xem review">
                                                </div>
                                            <?php elseif($type == 3): ?>
                                                <div class="form-group">
                                                    <label>Link tải game</label>
                                                    <input class="form-control" name="content[link_download]" value="<?php echo e(!empty($link_download) ? $link_download : ''); ?>" type="text" placeholder="Link tải game">
                                                </div>
                                                <div class="form-group">
                                                    <label>Link xem review</label>
                                                    <input class="form-control" name="content[link_review]" value="<?php echo e(!empty($link_review) ? $link_review : ''); ?>" type="text" placeholder="Link xem review">
                                                </div>
                                            <?php else: ?>
                                                <div class="form-group">
                                                    <label>Link cược ngay</label>
                                                    <input class="form-control" name="content[link_bet]" value="<?php echo e(!empty($link_bet) ? $link_bet : ''); ?>" type="text" placeholder="Link cược ngay">
                                                </div>
                                                <div class="form-group">
                                                    <label>Link xem review</label>
                                                    <input class="form-control" name="content[link_review]" value="<?php echo e(!empty($link_review) ? $link_review : ''); ?>" type="text" placeholder="Link xem review">
                                                </div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-sm-4">
                            <div class="card">
                                <div class="card-header"><strong>Thông tin khác</strong></div>
                                <div class="card-body">
                                    <div class="form-group">
                                        <label>Logo nhà cái</label>
                                        <?php if(!empty($logo)): ?>
                                            <img src="<?php echo e($logo); ?>" id="lbl_img" class="img-fluid d-block" onclick="upload_file('chosefile','img')">
                                        <?php else: ?>
                                            <img src="<?php echo e(url('admin/images/no-image.jpg')); ?>" id="lbl_img" class="img-fluid d-block" onclick="upload_file('chosefile','img')">
                                        <?php endif; ?>
                                        <input type="hidden" id="hd_img" name="content[logo]" value="<?php echo e(!empty($logo) ? $logo: ''); ?>" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Thứ tự</label>
                                        <input class="form-control" name="order_by" value="<?php echo e(!empty($oneItem->order_by) ? $oneItem->order_by : 0); ?>" type="number" placeholder="Thứ tự" min="0">
                                    </div>
                                    <div class="form-group float-right">
                                        <button type="submit" class="btn btn-primary">Lưu trữ</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/admin/nha_cai/update.blade.php ENDPATH**/ ?>