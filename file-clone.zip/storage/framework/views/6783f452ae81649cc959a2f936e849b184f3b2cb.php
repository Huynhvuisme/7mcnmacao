<script type="application/ld+json"> {
        "@context": "https://schema.org/",
        "@type": "NewsArticle",
        "mainEntityOfPage": {
            "@type": "WebPage",
            "@id": "<?php echo e(getUrlPost($oneItem, 0)); ?>"
        },
        "headline": "<?php echo e(strip_quotes($oneItem->meta_title)); ?>",
        "image": "<?php echo e(url($oneItem->thumbnail)); ?>",
        "datePublished": "<?php echo e(date('c', strtotime($oneItem->displayed_time))); ?>",
        "dateModified": "<?php echo e(date('c', strtotime($oneItem->updated_time))); ?>",
        "author": {
            "@type": "Person",
            "name": "Trịnh Tuấn"
        },
        "publisher": {
            "@type": "Organization",
            "name": "7mcn88.com",
            "logo": {
              "@type": "ImageObject",
              "url": "https://7mcn88.com/web/images/logo.svg?3"
            }
        },
        "description": "<?php echo e($seo_data['meta_description'] ?? ''); ?>"
    }
</script>
<?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/web/block/_schema_post.blade.php ENDPATH**/ ?>