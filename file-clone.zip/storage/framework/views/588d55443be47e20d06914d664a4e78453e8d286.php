<?php
    $firstPost = $posts[0];
    unset($posts[0]);
?>
<div class="post-cate col-sm-12 mb-3">
    <div class="first-post">
        <a href="<?php echo e(getUrlPost($firstPost)); ?>">
            <?php echo genImage($firstPost->thumbnail, 1000, 600, $firstPost->title, 'img-fluid'); ?>

        </a>
        <div class="first-post-content">
            <a href="<?php echo e(getUrlPost($firstPost)); ?>">
                <div class="first-post-title"><h3 class="text-white"><?php echo e($firstPost->title ?? ''); ?></h3></div>
                <div class="first-post-cate font-12">
                    <span><?php echo e($firstPost->category ? $firstPost->category->title : ''); ?></span> -
                    <span><?php echo e($firstPost->displayed_time); ?></span>
                </div>
            </a>
        </div>
    </div>
    <?php if(!empty($is_home)): ?>
    <div class="d-md-none my-2">
        <?php echo getBanner('home-center')?>
    </div>
    <?php endif; ?>
    <?php if(!IS_MOBILE): ?>
        <div class="top-post-after">
            <div class="row">
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="col-sm-3">
                        <a href="<?php echo e(getUrlPost($post)); ?>">
                            <?php echo genImage($post->thumbnail, 400, 250, $firstPost->title, 'img-fluid'); ?>

                        </a>
                        <div class="content">
                            <h3 class="line-height-22"><a class="text-dark font-16 font-weight-bold" href="<?php echo e(getUrlPost($post)); ?>"> <?php echo e($post->title); ?> </a></h3>
                        </div>
                    </div>
                    <?php
                        unset($posts[$key]);
                        if($loop->index >=3) break; // list 4 post
                    ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    <?php else: ?>
        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="py-3 border-bottom border-grey p-2">
                <div class="row">
                    <div class="col-6 col-lg-4">
                        <a href="<?php echo e(getUrlPost($item)); ?>">
                            <?php echo genImage($item->thumbnail, 500, 300, $item->title, 'img-fluid'); ?>

                        </a>
                    </div>
                    <div class="col-6 col-lg-8 pl-0">
                        <h3><a class="font-weight-bold font-md-18 text-dark d-block mb-2 font-16 line-height-24" href="<?php echo e(getUrlPost($item)); ?>"><?php echo e($item->title); ?></a></h3>
                        <div class="cate font-12 text-red2"><?php echo e(isset($item->category) ? $item->category->title : ''); ?></div>
                        <p class="d-none d-lg-block line-height-24 font-14"><?php echo get_limit_content($item->description, 400); ?></p>
                    </div>
                </div>
            </div>
            <?php
                unset($posts[$key]);
                if($loop->index >=3) break; // list 4 post
            ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
    <?php if(!empty($is_home)): ?>
        <div class="my-2 d-none d-md-block">
            <?php echo getBanner('home-center')?>
        </div>
    <?php endif; ?>
</div>
<?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/web/block/_top_post.blade.php ENDPATH**/ ?>