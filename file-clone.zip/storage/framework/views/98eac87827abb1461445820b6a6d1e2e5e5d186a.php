<div id="fb-root"></div>
<header>
    <div class="container p-0 px-md-3 pb-5 pb-md-4 pb-lg-5">
        <div class="bg-green4 pl-3 d-none d-lg-flex header-banner justify-content-center align-items-center" style="min-height: 130px;">
            <a href="/">
                <img title="<?php echo e(getSiteSetting('site_logo_title')); ?>" class="img-fluid" src="/web/images/logo-7mcn88.jpg" alt="<?php echo e(getSiteSetting('site_logo_alt')); ?>" width="300" height="50">
            </a>
            <div class="d-flex text-white justify-content-center align-items-center" style="width: 728px;height:90px;">
                <?php echo getBanner('header-pc')?>
            </div>
        </div>
    </div>
</header>
<div class="container mt-n5 mt-md-n4 mt-lg-n5 nav-menu position-sticky px-0 px-md-3">
    <nav class="navbar navbar-expand-lg navbar-dark bg-green4 rounded-lg-top p-2 m-0 p-md-0 nav-menu position-sticky">
        <a class="navbar-brand navbar-toggler border-0 m-0 p-0" href="/">
            <img src="/web/images/logo-7mcn88.jpg" class="img-fluid" alt="7mcn88" width="200" height="30">
        </a>
        <button class="navbar-toggler border-0 m-0 p-0" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" <?php if(IS_AMP): ?> on="tap:navbarSupportedContent.toggleClass(class='show')" <?php endif; ?>>
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse bg-green5" id="navbarSupportedContent">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item d-lg-none">
                    <form method="get" action="/tim-kiem" target="_top" class="form-inline my-2 d-flex flex-nowrap">
                        <input name="q" class="form-control mr-sm-2 font-13 text-white w-100 pl-3" style="background: none;border:none;" type="search" placeholder="Từ khóa tìm kiếm" aria-label="Search">
                        <button class="btn my-2 my-sm-0 p-0" type="submit"><img src="/web/images/icon-search.svg" alt="search icon" width="18" height="18"></button>
                    </form>
                </li>
                <li class="nav-item active d-none d-lg-block">
                    <a class="nav-link" href="/"><img src="/web/images/home.svg?v=2" alt="7mcn88" height="19" width="19"></a>
                </li>

                <?php if(!empty($mainMenuPc)): ?>
                    <?php $__currentLoopData = $mainMenuPc; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item d-none d-lg-block dropdown position-relative">
                            <a class="nav-link text-uppercase px-2" title="<?php echo e($item['name']); ?>" href="<?php echo e(getFullUrl($item['url'])); ?>"><?php echo e($item['name']); ?></a>
                            <?php if(!empty($item['children'])): ?>
                                <div class="dropdown-content position-absolute bg-green5">
                                    <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <a class="text-uppercase px-3 py-2 d-block nav-link" title="<?php echo e($value['name']); ?>" href="<?php echo e(getFullUrl($value['url'])); ?>"><?php echo e($value['name']); ?></a>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endif; ?>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>

                <?php if(!empty($mainMenuMobile)): ?>
                    <?php $__currentLoopData = $mainMenuMobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="nav-item d-lg-none">
                        <a class="nav-link text-uppercase" title="<?php echo e($item['name']); ?>" href="<?php echo e(getFullUrl($item['url'])); ?>"><?php echo e($item['name']); ?></a>
                        <?php if(!empty($item['children'])): ?>
                            <div class="pl-3">
                                <?php $__currentLoopData = $item['children']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a class="nav-link text-uppercase" title="<?php echo e($value['name']); ?>" href="<?php echo e(getFullUrl($value['url'])); ?>"><?php echo e($value['name']); ?></a>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endif; ?>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
            </ul>
        </div>
    </nav>
</div>
<div class="d-lg-none list-banner-mobi">
    <?php echo getBanner('header-mobile')?>
</div>

<div class="container popup-banner d-none d-lg-block">
    <?php echo getBannerPC('full-width-pc'); ?>

</div>

<?php /**PATH D:\work\7mcn88\resources\views/web/header.blade.php ENDPATH**/ ?>