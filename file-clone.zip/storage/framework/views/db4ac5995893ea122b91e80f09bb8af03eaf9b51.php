
<?php $__env->startSection('content'); ?>
    <main class="c-main">
        <div class="container-fluid">
            <div class="fade-in">
                <div class="card">
                    <div class="card-header">
                        Danh sách chuyên mục
                        <div class="card-header-actions ml-3">
                            <a href="/admin/category/export-excel" id="export-excel" class="btn btn-block btn-primary btn-sm mr-3">Xuất file excel</a>
                        </div>
                        <div class="card-header-actions pr-1">
                            <a href="/admin/category/update"><button class="btn btn-block btn-primary btn-sm mr-3" type="button">Thêm mới</button></a>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-striped table-bordered datatable">
                            <thead>
                            <tr>
                                <th class="text-center w-5">ID</th>
                                <th>Tiêu đề</th>
                                <th class="text-center w-15">Thao tác</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php if(!empty($listItem)): ?> <?php $__currentLoopData = $listItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($item->id); ?></td>
                                    <td><a target="_blank" href="<?php echo e(getUrlCate($item)); ?>"><?php echo e($item->title); ?></a> - <span class="text-success"><?php echo e($item->count_post); ?> bài viết</span></td>
                                    <td class="text-center">
                                        <a class="btn btn-info" href="/admin/category/update/<?php echo e($item->id); ?>"><svg class="c-icon"><use xlink:href="/admin/images/icon-svg/free.svg#cil-pencil"></use></svg></a>
                                        <a class="btn btn-danger" onclick="return confirm('Bạn có chắc muốn xóa?')" href="/admin/category/delete/<?php echo e($item->id); ?>"><svg class="c-icon"><use xlink:href="/admin/images/icon-svg/free.svg#cil-trash"></use></svg></a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </main>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/admin/category/index.blade.php ENDPATH**/ ?>