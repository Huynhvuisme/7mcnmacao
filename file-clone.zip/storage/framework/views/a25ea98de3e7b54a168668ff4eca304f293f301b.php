
<?php $__env->startSection('content'); ?>
    <main class="c-main">
        <div class="container-fluid">
            <div class="fade-in">
                <form method="post" action="">
                    <div class="row">
                        <div class="col-sm-12">
                            <div class="card">
                                <div class="card-header"><strong><?php echo e(!empty($oneItem) ? 'Chỉnh sửa' : 'Thêm mới'); ?> Menu</strong></div>
                                <div class="card-body">
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>Tên menu</label>
                                                <input class="form-control" name="name" value="<?php echo e(!empty($oneItem->name) ? $oneItem->name : ''); ?>" type="text" placeholder="Tên menu" required>
                                                <input type="hidden" name="data" value="<?php echo e(!empty($oneItem->data) ? $oneItem->data : ''); ?>">
                                            </div>
                                            <h5>Chọn chuyên mục</h5>
                                            <div class="row mb-1">
                                                <div class="form-group col-9">
                                                    <select class="form-control" name="category_id">
                                                        <option value="" data-url=""
                                                                data-title="" selected disabled>Select category</option>
                                                        <?php $__currentLoopData = $categoryTree; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <option value="<?php echo e($item['id']); ?>" data-url="<?php echo e(preg_replace('/http.*?\/\/7mcn88.*?\//', '/', getUrlCate($item))); ?>"
                                                                    data-title="<?php echo e($item['title']); ?>"><?php echo e($item['title']); ?></option>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    </select>
                                                </div>
                                                <div class="text-center col-3">
                                                    <button type="button" class="category_select btn-select btn btn-theme border">Chọn &gt;&gt;</button>
                                                </div>
                                            </div>
                                            <h5>Link khác</h5>
                                            <div class="row mb-1">
                                                <div class="col-9">
                                                    <input type="text" class="form-control" name="custom_link" placeholder="link">
                                                </div>
                                                <div class="text-center col-3">
                                                    <button type="button" class="link_select btn-select btn btn-theme border">Chọn &gt;&gt;</button>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-sm-3"></div>
                                        <div class="col-sm-3">
                                            <div class="cf nestable-lists">
                                                <div class="dd" id="nestable">
                                                    <ol class="dd-list"></ol>
                                                </div>
                                            </div>
                                            <div class="form-group float-right">
                                                <button type="submit" class="btn btn-primary">Lưu trữ</button>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </main>
    
    <div class="modal fade" id="smallModal" tabindex="-1" aria-labelledby="myModalLabel" style="display: none;" aria-hidden="true">
        <div class="modal-dialog modal-sm" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <p>Bạn có muốn xóa?</p>
                </div>
                <div class="modal-footer">
                    <button class="btn btn-primary confirm_yes" type="button">Yes</button>
                    <button class="btn btn-secondary" type="button" data-dismiss="modal">No</button>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/vtiwqelehosting/public_html/7mcnmacao.com/resources/views/admin/menu/update.blade.php ENDPATH**/ ?>