@extends('admin.layout')
@section('content')
    <main class="c-main">
    </main>
@endsection
