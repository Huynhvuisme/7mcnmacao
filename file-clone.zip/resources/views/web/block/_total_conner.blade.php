<table class="table table-sm table-responsive table-striped table-bordered table-hover deep_blue_head bg-white font-14 w-100 totalcorner"> 
    <thead>
        <tr>
            <th class="text-center th_league">Giải đấu</th>
            <th class="text-center th_start_time">Thời gian</th>
            <th class="text-center match_status th_status">🕑</th>
            <th class="text-center th_home">Đội nhà</th>
            <th class="text-center th_corner">Tỷ số phạt góc</th>
            <th class="text-center th_away">Đội khách</th>
        </tr>
        </thead>
    {!!$tbody!!}
</table>